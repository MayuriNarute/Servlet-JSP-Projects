package com.Dao;
import com.Model.*;
import java.util.*;
import java.sql.*;
import java.util.Scanner;
public class CustomerDao {

	Connection con = null;
	MyConnection m = new MyConnection();
	PreparedStatement ps;
	Scanner sc = new Scanner(System.in);
	public int register(Register r){
		con=m.getConnection();
		int i=0;
		try {		
			ps=con.prepareStatement("insert into jsp_customer values(?,?,?,?,?,?,?)");
			ps.setInt(1, r.getCid());
			ps.setString(2, r.getFname());
			ps.setString(3, r.getLname());
			ps.setString(4, r.getBday());
			ps.setString(5, r.getGender());
			ps.setString(6, r.getEmail());
			ps.setString(7, r.getMobno());
			i = ps.executeUpdate();
			if (i>0) {
				System.out.println("added successfully!");
				return i;
			}
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public List<Register> DisplayAccount()
	{
		ResultSet rs=null;
		Register r=null;
		LinkedList<Register> lst=new LinkedList<>();
		con=m.getConnection();
		Statement state=null;
		String str=null;
		int i=0;
		try
		{
			state=con.createStatement();
			rs=state.executeQuery("select * from jsp_customer");
					
			while(rs.next())
			{
				r=new Register();
				r.setCid(rs.getInt(1));
				r.setFname(rs.getString(2));
				r.setLname(rs.getString(3));
				r.setBday(rs.getString(4));
				r.setGender(rs.getString(5));
				r.setEmail(rs.getString(6));
				r.setMobno(rs.getString(7));
				lst.add(r);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return lst;
	}
	public List<Register> SearchAccount(int cid)
	{
		List<Register> lst=null;
		con=m.getConnection();
		try
		{
			PreparedStatement ps=con.prepareStatement("select * from jsp_customer where cust_uid=?");
			ps.setInt(1,cid);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				Register r=new Register();
				r.setCid(rs.getInt(1));
				r.setFname(rs.getString(2));
				r.setLname(rs.getString(3));
				r.setBday(rs.getString(4));
				r.setGender(rs.getString(5));
				r.setEmail(rs.getString(6));
				r.setMobno(rs.getString(7));
				lst=new LinkedList<Register>();
				lst.add(r);			
			}
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return lst;
	}
	public int update(Register r,int curr_uid){
		con=m.getConnection();
		int i = 0;
		try {
			ps = con.prepareStatement("update jsp_customer set cust_uid = ?,first_name = ?,last_name = ?,birth_date = ?,gender = ?,mail = ?,mobile = ? where cust_uid = ?");
			ps.setInt(1, r.getCid());
			ps.setString(2, r.getFname());
			ps.setString(3, r.getLname());
			ps.setString(4, r.getBday());
			ps.setString(5, r.getGender());
			ps.setString(6, r.getEmail());
			ps.setString(7, r.getMobno());
			ps.setInt(8, curr_uid);
			i = ps.executeUpdate();
			if (i>0) {
				System.out.println("updated successfully!");
				return i;
			}
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return i;
	}
	public int delete(int uid){
		con=m.getConnection();
		int i = 0;
		try {
			ps = con.prepareStatement("delete from jsp_customer where cust_uid = ?");
			ps.setInt(1, uid);
			i = ps.executeUpdate();
			if (i>0) {
				System.out.println("deleted successfully!");
				return i;
			}
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return i;
	}
}

