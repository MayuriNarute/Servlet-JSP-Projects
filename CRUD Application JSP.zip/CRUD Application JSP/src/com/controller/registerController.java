package com.controller;
import java.util.*;

import com.Dao.CustomerDao;
import com.Model.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class registerController
 */
@WebServlet("/registerController")
public class registerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       List<Register> lstc=null;
	public void init()
	{
		lstc=new LinkedList<Register>();
	}
    /**
     * @see HttpServlet#HttpServlet()
     */
    public registerController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter pw=response.getWriter();
		String msg=null;
		int cid=Integer.parseInt(request.getParameter("uid"));
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String bd=request.getParameter("bday");
		String gender=request.getParameter("gender");
		String mail=request.getParameter("email");
		String mob=request.getParameter("phone");
		Register r = new Register(cid, fname, lname, bd, gender, mail, mob);
		CustomerDao dao = new CustomerDao();
		int j=dao.register(r);
		HttpSession ses=request.getSession(true);
		if (j>0) {
			msg="Register SuccessFully";
			response.sendRedirect("Register.jsp");
		}
		else {
			msg="Not Registered";
			response.sendRedirect("Register.jsp");
		}
		ses.setAttribute("register", msg);
		/*lstc.add(r);
		 * 
		for(Register p:lstc)
		{
			pw.print(p.getFname()+"\n");
			pw.print(p.getLname()+"\n");
			pw.print(p.getBday()+"\n");
			pw.print(p.getGender()+"\n");
			pw.print(p.getEmail()+"\n");
			pw.print(p.getMobno()+"\n");
		}*/
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
