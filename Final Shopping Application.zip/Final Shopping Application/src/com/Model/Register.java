package com.Model;

public class Register {

	private int custid;
	private String fname;
	private String lname;
	private	int mobno;
	private String mail;
	private String uname;
	private String pass;
	public Register()
	{
		
	}
	public Register(int custid, String fname,String lname,int mobno,String mail,String uname,String pass) {
		this.custid=custid;
		this.fname=fname;
		this.lname=lname;
		this.mobno=mobno;
		this.mail=mail;
		this.uname=uname;
		this.pass=pass;
	}
	
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getMobno() {
		return mobno;
	}
	public void setMobno(int mobno) {
		this.mobno = mobno;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
}
