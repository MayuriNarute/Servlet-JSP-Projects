package com.Controller;
import com.Dao.ProductDao;
import com.Model.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DisplayController
 */
@WebServlet("/DisplayController")
public class DisplayController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DisplayController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession ses=request.getSession(true);
		HttpSession ses2=request.getSession(true);

		PrintWriter pw=response.getWriter();

		//RegisterDao rd=new RegisterDao();
		Register r=(Register)ses2.getAttribute("register");
		Bill b=(Bill)ses.getAttribute("billobj");
		ProductDao pdao=new ProductDao();
		pw.print("<html><head><style>body{ "
				+ "background-image: url('bg3.jpg');"
				+ "background-repeat: no-repeat;"
				+ "	background-size: cover;"
				+ "	background-attachment: fixed;" 
				+"	background-position: center center;"
				+ "}"
				+ " </style></head><body>");
		pw.print("<h1><center><u>Customer Details</u></center></h1>");
		//pw.println("<html><body>");  
		pw.println("<table style='font-size:26px' align='center' bgcolor='linen' border=1 width=50% height=20%>");
		pw.println("<th>Customer ID</th><th>FirstName</th><th>LastName</th><th>Mobile No</th><th>E-Mail</th><th>UserName</th><th>Password</th>"); 


		pw.println("<tr align='center'><td>"+r.getCustid()+"</td><td>"+r.getFname()+"</td><td>"+r.getLname()+"</td><td>"+r.getMobno()+"</td><td>"+r.getMail()+"</td><td>"+r.getUname()+"</td><td>"+r.getPass()+"</td></tr>");    

		pw.println("</table>");  
		List<Product> lstprod=(List)ses.getAttribute("prod");

		pw.println("<h1><center><u>Product Details</u></center></h1>"); 
		pw.println("<table style='font-size:26px' align='center' bgcolor='linen' border=1 width=50% height=30%>");
		pw.println("<tr><th>UserName</th><th>Product ID</th><th>Product Name</th><th>Product Price</th><th>Product Quantity</th>");
		//
		for(Product p:lstprod) {
			pw.println("<tr align='center'>");
			pw.println("<td>"+p.getUsername()+"</td>");

			pw.println("<td>"+p.getProdid()+"</td>");
			pw.println("<td>"+p.getProdname()+"</td>");
			pw.println("<td>"+p.getProdprice()+"</td>");
			pw.println("<td>"+p.getProdqty()+"</td>"); 
			pw.println("</tr>"); 
		}
		pw.println("</table>"); 
		
		pw.print("<br><h2><center>----FINAL BILL----</center></h2>");

		pw.println("<table style='font-size:29px' align='center' bgcolor='linen' border=1 width=40% height=30%>");
		pw.println("<tr><th>UserName</th><th>Bill No</th><th>Total</th><th>CGST</th><th>SGST</th><th>Final Total</th>");
		
			pw.print("<tr align='center'>");
			pw.print("<td>"+b.getUsername()+"</td>");

			pw.print("<td>"+b.getBillno()+"</td>");
			pw.print("<td>"+b.getTotal()+"</td>");

			pw.print("<td>"+b.getCgst()+"</td>");

			pw.print("<td>"+b.getSgst()+"</td>");

			pw.print("<td>"+b.getFinaltotal()+"</td>");
			pw.print("</tr>");
			
		pw.println("</table>");
		pdao.setbill(b);
		//lstprod=b.getLstprod();

		
		pw.print("<center><h2>-----THANK YOU----</h2>");
		pw.print("<form action='Home.html'><br><h1>Go to Home Page -</h1><br>");
		pw.print("<br><input style='font-size:28px' type='submit' align='center' value='  YES  '</input></form></center><br>");
		pw.print("</center></body></html>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
