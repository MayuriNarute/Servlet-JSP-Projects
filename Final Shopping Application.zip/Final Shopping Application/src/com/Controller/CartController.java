package com.Controller;
import com.Dao.ProductDao;
import com.Model.*;
import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class CartController
 */
@WebServlet("/CartController")
public class CartController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CartController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		ProductDao pdao=new ProductDao();
		//pw.print("\n\t----PRODUCT LIST------");
		HttpSession ses=request.getSession(true);
		Login l=new Login();
		List<Product> lstp=(List)ses.getAttribute("prod");
		
		pw.println("<html><style>"
				+ "body{"
				+ "background-image:url('bg.jpg');"
				+ "background-repeat:no-repeat;"
				+ "background-size:cover;}"
				+ "h1{"
				+ "color:white;}"
				+ "<body>");
		pw.println("<h1><center><u>Product Details</u></center></h1>"); 
		pw.println("<table align='center' bgcolor='white' border=1 width=50% height=50%>");
		pw.println("<tr><th>Product ID</th><th>Product Name</th><th>Product Price</th><th>Product Quantity</th>");
		for(Product pd:lstp)
		{
			pw.println("<tr align='center'>");
			pw.println("<td>"+pd.getProdid()+"</td>");
			pw.println("<td>"+pd.getProdname()+"</td>");
			pw.println("<td>"+pd.getProdprice()+"</td>");
			pw.println("<td>"+pd.getProdqty()+"</td>"); 
			pw.println("</tr>"); 
		}
		pw.println("</table>"); 
		pw.println("</html></body>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
