package com.Controller;
import com.Dao.MyConnection;
import com.Dao.RegisterDao;
import com.Model.*;
import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		HttpSession ses=request.getSession(true);
		Register r=(Register)ses.getAttribute("register");
		String uname=request.getParameter("uname");
		String pass=request.getParameter("pass");
		Login l=new Login();
		l.setUname(uname);
		l.setPass(pass);
		RegisterDao rd=new RegisterDao();
		boolean b=rd.validateUser(l);
		pw.print("<html><head>");
		if(b)
		{
			pw.print("<style>input{"
					+ "font-size:28px;"
					+ "border-radius:20px;"
					+ "text-align:center;"
					+ "}"
					+ "body{"
					+ "background-image:url('girl3.jpg');</style></head><body bgcolor='cyan'>");
			pw.print("<center><h1>|*  Logged In SuccessFully * |</h1><br>");
		//	response.sendRedirect("ProductAdd.html");

			
			pw.print("<form action='ProductAdd.html'><br>");
			pw.print("<br><input  type='submit' align='left' value=' Purchase Products  '</input></form></center><br>");
			
			pw.print("<form action='HistoryServlet'><br>");
			pw.print("<br><input  type='submit' align='left' value='View History '</input></form></center><br>");
			
			//pw.print("<br><center><img src='girl3.jpg'  width='80%'></center></img>");
			pw.print("</html></body>");
		}
		else
		{
		
			pw.print("<h1><center>Oops ! Something Went Wrong...Please try again later...</center></h1>");
			
		}
		pw.print("</html></body>");
		ses.setAttribute("Login",l);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
