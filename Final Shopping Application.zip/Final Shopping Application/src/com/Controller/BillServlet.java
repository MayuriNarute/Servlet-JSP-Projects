package com.Controller;
import java.util.List;
import com.Model.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.*;
/**
 * Servlet implementation class BillServlet
 */
@WebServlet("/BillServlet")
public class BillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession sest=request.getSession(true);
		//ProductDao pdao=new ProductDao();
		List<Product> lstProd=(List)sest.getAttribute("prod");
		Register r=(Register)sest.getAttribute("register");
		Login l=new Login();
		float total=0,sgst=0,cgst=0,finaltotal=0;
		for(Product p:lstProd)
		{
			total=total+p.getProdprice()*p.getProdqty();
			
		}
		cgst=total*0.06f;
		sgst=total*0.07f;
		finaltotal=total+sgst+cgst;
		
		Bill bill=new Bill(l.getUname(),112, total, cgst, sgst, finaltotal);
		//bill.setLstprod(lstProd);
		sest.setAttribute("billobj", bill);
		response.sendRedirect("DisplayController");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
