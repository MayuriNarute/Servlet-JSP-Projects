package com.Controller;
import com.Model.*;
import java.io.IOException;
//import java.io.PrintWriter;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.RegisterDao;
import com.Model.Register;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 * Servlet implementation class RegisterController
 */
@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession ses=request.getSession(true);
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int cid=Integer.parseInt(request.getParameter("custid"));
		String fn=request.getParameter("fname");
		String ln=request.getParameter("lname");
		int mob=Integer.parseInt(request.getParameter("mobno"));
		String mai=request.getParameter("mail");
		String un=request.getParameter("un");
		String pass=request.getParameter("pa");

		Register reg=new Register();
		reg.setCustid(cid);
		reg.setFname(fn);
		reg.setLname(ln);
		reg.setMobno(mob);
		reg.setMail(mai);
		reg.setUname(un);;
		reg.setPass(pass);
		
		RegisterDao rd=new RegisterDao();
		
		int i=rd.createAccount(reg);
		if(i>0)
		{
			pw.print("<html><body bgcolor='cyan'>");
			pw.print("<center><h1>| * Register SuccessFully  * |</h1><br>");
		//	response.sendRedirect("ProductAdd.html");

			
			pw.print("<form action='Home.html'><br><h1>Go to Home Page -</h1><br>");
			pw.print("<br><input style='font-size:28px' type='submit' align='center' value='  YES  '</input></form></center><br>");
			pw.print("<br><center><img src='girl1.jpg' height='80%' width='80%'></center></img>");

			pw.print("</body></html>");
		}
		else
		{
			pw.print("<html><body bgcolor='cyan'>");
			pw.print("<h1><center>Oops ! Something Went Wrong..Please try again Later !</center></h1>");
			pw.print("</body></html>");
		}
		ses.setAttribute("register", reg);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
