package com.Controller;
import com.Dao.ProductDao;
import com.Model.*;
import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class ProductController
 */
@WebServlet("/ProductController")
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductController() {
        super();
        // TODO Auto-generated constructor stub
    }	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		ProductDao pdao=new ProductDao();
		HttpSession ses=request.getSession(true);
		HttpSession ses2=request.getSession(true);
		int prodid=Integer.parseInt(request.getParameter("pid"));
		String prodname=request.getParameter("pname");
		float pprice=Float.parseFloat(request.getParameter("pprice"));
		int prodqty=Integer.parseInt(request.getParameter("pqty"));
		Login rd=(Login)ses.getAttribute("Login");
		
		Product prod=new Product(rd.getUname(),prodid, prodname, pprice, prodqty);
		pdao.SaveData(prod);
		List<Product> plst=new LinkedList<Product>();
		plst=pdao.retrive(prod);
		ses2.setAttribute("prod",plst);
		pw.print("<html><body bgcolor='orange'><center>");
		pw.print("<form action='ProductAdd.html'><h2>Do you want to Add More Products in Cart Click Yes<br>");
		pw.print("<br><input style='font-size:28px'type='submit' align='center' value='  YES  '</input></form><br><br>");
			
		pw.print("<form action='CartController'><br>To Confirm Product Click Yes :<br>");
		pw.print("<br><input style='font-size:28px' type='submit' align='center' value='  YES  '</input></form><br>");
		
		pw.print("<form action='BillServlet'><br>To Get The Bill Click Yes :<br>");
		pw.print("<br><input style='font-size:28px' type='submit' align='center' value='  YES  '</input></form><br>");
		pw.print("</h2></center></body></html>");
		
		pw.print("</h2></center></body></html>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
