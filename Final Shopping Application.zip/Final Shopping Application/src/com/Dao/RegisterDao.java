package com.Dao;
import java.util.*;
import com.Model.*;
import java.sql.*;
import java.util.*;

import com.Model.Register;
public class RegisterDao {

	Connection con=null;
	MyConnection m=new MyConnection();
	PreparedStatement pstate=null;
	int i=0;
	public boolean validateUser(Login l)
	{
		boolean b=false;
		con=m.getConnection();
		try
		{
			PreparedStatement ps=con.prepareStatement("select * from customerinfo where username=? and password=?");
			ps.setString(1,l.getUname());
			ps.setString(2,l.getPass());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				b=true;
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
		return b;
	}
	public int createAccount(Register r)
	{

		con=m.getConnection();
		try
		{
			pstate=con.prepareStatement("insert into customerinfo values(?,?,?,?,?,?,?)");
			pstate.setInt(1,r.getCustid());
			pstate.setString(2,r.getFname());
			pstate.setString(3,r.getLname());
			pstate.setInt(4,r.getMobno());
			pstate.setString(5, r.getMail());
			pstate.setString(6, r.getUname());

			pstate.setString(7, r.getPass());
			i=pstate.executeUpdate();
			con.close();

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return i;
	}
	public List<Register> DisplayAccount()
	{
		ResultSet rs=null;
		Register r=null;
		LinkedList<Register> lst=new LinkedList<>();
		con=m.getConnection();
		Statement state=null;
		String str=null;
		int i=0;
		try
		{
			state=con.createStatement();
			rs=state.executeQuery("select * from customerinfo");
					
			while(rs.next())
			{
				r=new Register();
				r.setCustid(rs.getInt(1));
				r.setFname(rs.getString(2));
				r.setLname(rs.getString(3));
				r.setMobno(rs.getInt(4));
				r.setMail(rs.getString(5));
				r.setUname((rs.getString(6)));
				r.setPass((rs.getString(7)));
				lst.add(r);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return lst;
	}
}