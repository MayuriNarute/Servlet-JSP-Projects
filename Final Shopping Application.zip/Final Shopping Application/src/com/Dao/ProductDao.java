package com.Dao;
import com.Model.*;
import java.util.*;
//import java.util.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;
public class ProductDao {

	Connection con=null;
	MyConnection m=new MyConnection();
	PreparedStatement pstate=null;
	int i=0;
	public void SaveData(Product p)
	{
		//List<Product> plst=bobj.getLstprod();
		//for(Product p:plst)
		//{
			con=m.getConnection();
			try
			{
				PreparedStatement ps1=con.prepareStatement("insert into productinfo values(?,?,?,?,?)");
				ps1.setString(1,p.getUsername());
				ps1.setInt(2,p.getProdid());
				ps1.setString(3, p.getProdname());
				ps1.setFloat(4, p.getProdprice());
				ps1.setInt(5, p.getProdqty());
				i=ps1.executeUpdate();
				if(i>0)
				{
					System.out.println("\n\t...Product save in DB....");
				}
				con.close();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}

	}
	public void setbill(Bill b)
	{
		con=m.getConnection();
		try
		{
			PreparedStatement ps2=con.prepareStatement("insert into billinfo values(?,?,?,?,?,?)");
			ps2.setString(1,b.getUsername());
			ps2.setInt(2,b.getBillno());
			ps2.setFloat(3,b.getTotal());
			ps2.setFloat(4,b.getCgst());
			ps2.setFloat(5, b.getSgst());
			ps2.setFloat(6, b.getFinaltotal());
			i=ps2.executeUpdate();
			if(i>0)
			{
				System.out.println("\n\t...Bill save in DB....");
			}
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public List<Product> retrive(Product p)
	{
		List<Product> lstp=new LinkedList<Product>();
		con=m.getConnection();
		
		try
		{

			PreparedStatement pstate=con.prepareStatement("select * from productinfo where username=?");//101
			pstate.setString(1,p.getUsername());
			ResultSet rs=pstate.executeQuery();//select
			while(rs.next()==true)
			{
				//p=new Product();

				p=new Product(rs.getString(1), rs.getInt(2),rs.getString(3), rs.getFloat(4),rs.getInt(5));
				lstp.add(p);
			}	
			con.close();
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstp;
	}
	 
}
